package com.example.book_tracker

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.book_tracker.databinding.AddlistPageBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class AddListActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var database: FirebaseDatabase
    private lateinit var binding: AddlistPageBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = AddlistPageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initialize Firebase authentication and database instances
        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance()

        // Set up the button click listener to add a list to Firebase
        binding.submit.setOnClickListener {
            val listName = binding.listEditText.text.toString().trim()

            // Check if the list name is empty and show a toast if it is
            if (listName.isEmpty()) {
                Toast.makeText(this, "Please enter your List name.", Toast.LENGTH_SHORT).show()
            } else {
                // Add the list name to Firebase under the current user's node
                addListToFirebase(listName)
            }
        }

        // Set up the back button to close this activity
        binding.backBtn.setOnClickListener {
            finish() // Closes AddListActivity and returns to LibraryActivity
        }
    }

    private fun addListToFirebase(listName: String) {
        // Get the user ID for storing the list data
        val userId = auth.currentUser?.uid
        if (userId != null) {
            // Reference to user's "lists" node in Firebase
            val userListsRef = database.reference.child("users").child(userId).child("lists")

            // Add the list name to the database as a unique child
            val newListRef = userListsRef.push()
            newListRef.setValue(listName).addOnSuccessListener {
                // Show success message and clear the input field
                Toast.makeText(this, "List added successfully.", Toast.LENGTH_SHORT).show()
                binding.listEditText.text?.clear() // Clears the EditText field
            }.addOnFailureListener {
                // Show error message if the save operation fails
                Toast.makeText(this, "Failed to add list. Try again.", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "User not authenticated.", Toast.LENGTH_SHORT).show()
        }
    }
}
