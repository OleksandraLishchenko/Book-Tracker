package com.example.book_tracker

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.book_tracker.databinding.LibraryPageBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class LibraryActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var database: FirebaseDatabase
    private lateinit var adapter: ListAdapter
    private val listNames = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.library_page)

        // Initialize Firebase instances
        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance()

        // Set up RecyclerView with the adapter
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        adapter = ListAdapter(listNames)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        // Load the list data from Firebase
        loadListData()

        // Navigate to AddListActivity when "Add List" button is clicked
        findViewById<Button>(R.id.addlist).setOnClickListener {
            startActivity(Intent(this, AddListActivity::class.java))
        }
    }

    private fun loadListData() {
        // Get the user ID and fetch list data from Firebase
        val userId = auth.currentUser?.uid ?: return
        database.reference.child("users").child(userId).child("lists")
            .get().addOnSuccessListener { snapshot ->
                // Clear current list and add new items from database
                listNames.clear()
                for (item in snapshot.children) {
                    val name = item.getValue(String::class.java)
                    name?.let { listNames.add(it) }
                }
                // Notify adapter to refresh RecyclerView data
                adapter.notifyDataSetChanged()
            }.addOnFailureListener {
                // Handle the error case (optional)
                Toast.makeText(this, "Failed to load lists.", Toast.LENGTH_SHORT).show()
            }
    }
}
